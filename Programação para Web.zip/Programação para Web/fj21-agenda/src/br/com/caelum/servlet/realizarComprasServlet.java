package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ProdutoDAO_Estoque;
import br.com.caelum.modelo.Produto;

@WebServlet(name="listaTabela", urlPatterns = {"/realizarCompra"})
public class realizarComprasServlet extends HttpServlet{
	protected void service(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException ,IOException {
		
		try {
			ArrayList<Produto> listaProduto = new ArrayList<Produto>();
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			ProdutoDAO_Estoque dao = new ProdutoDAO_Estoque();
			dao.listaCompraProdutos(listaProduto);
			Produto p = new Produto();
		    out.println("<html>");
			out.println("<body>");
			out.println("<center><p style=\"font-size: 30px; color#767676\">Lista de Produtos</p>"); 
			out.println("<table border = 1 >");
			out.println("<tr>");
			out.println("<th>ID</th> ");
			out.println("<th>Marca</th>");
			out.println("<th>Preco Unitario</th>");
			out.println("<th>Quantidade no Estoque</th>");
			out.println("<th><oi</th>");
			out.println("</tr>");
			for(Produto p1 : listaProduto){
				p = p1;
				 out.println("<tr>");
				 out.println("<th>"+p.getId()+"</th>");
					out.println("<th>"+p.getMarca()+"</th>");
					out.println("<th>"+p.getPreco()+"</th>");
					out.println("<th>"+p.getQuantidade_estoque()+"</th>");
					out.println("</tr>");
					out.println("</tbody>");
					out.println("</center></table>");
					out.println("<center><a href = \"http://localhost:8080/fj21-agenda/realizar-compra.html\">Efetuar Compra</a></center>");
					out.println("</div>");
					out.println("</form>");
					out.println("</section> ");
			} }catch (Exception e) {
			// TODO: handle exception
		}
	
	
}}

