package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ProdutoDAO_Estoque;
import br.com.caelum.modelo.Produto;

@WebServlet("/adicionaProduto")
public class AdicionaProdutoServlet extends HttpServlet {
 
	private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws  IOException,ServletException {
	
	
 PrintWriter out = response.getWriter();
//Busando os parametros do request

String marca = request.getParameter("marca");
String preco = request.getParameter("preco");
String fornecedor = request.getParameter("fornecedor");
String quantidade_estoque = request.getParameter("quantidade_estoque");

Produto produto = new Produto();
produto.setMarca(marca);
produto.setPreco(Float.parseFloat(preco));
produto.setFornecedor(fornecedor);
produto.setQuantidade_estoque(Integer.parseInt(quantidade_estoque));


	
	try {
		ProdutoDAO_Estoque novo = new ProdutoDAO_Estoque();
		
		novo.adiciona(produto);
   
	out.println("<html>");
	out.println("<body>");
	out.println("Produto  " + produto.getMarca() + " \n adicionado com sucesso!" );
	out.println("</body>");
	out.println("</html>");
	request.getRequestDispatcher("aviso.html").forward(request, response);
	out.println("<INPUT  TYPE=\"button\" VALUE =\"Voltar\" onClick=\"history.go(-1)\"/>");
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}


  }
  }

