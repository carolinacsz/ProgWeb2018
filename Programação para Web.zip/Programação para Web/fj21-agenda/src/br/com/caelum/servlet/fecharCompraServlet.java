package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ProdutoDAO_Estoque;
import br.com.caelum.modelo.Produto;

@WebServlet("/finalizarCompra")
public class fecharCompraServlet extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException ,IOException {
		
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		String quantidade_estoque = request.getParameter("quantidade_estoque");
	
		try {
			Produto novo = new Produto();
			novo.setQuantidade_estoque(Integer.parseInt(quantidade_estoque));
			novo.setId(Integer.parseInt(id));
			ProdutoDAO_Estoque f1 = new ProdutoDAO_Estoque();
			f1.finalizaCompra(novo);
			request.getRequestDispatcher("avisoMenu.html").forward(request, response);
			
			
		} catch (Exception e) {
			e.printStackTrace();// TODO: handle exception
		}
	}
	}
	

