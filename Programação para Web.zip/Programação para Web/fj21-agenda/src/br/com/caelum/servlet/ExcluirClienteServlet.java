package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ClienteDAO_Estoque;
import br.com.caelum.modelo.Cliente;


@WebServlet("/excluirCadastro")
public class ExcluirClienteServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws IOException,ServletException  {
		
		PrintWriter out = response.getWriter();
		String cpf = request.getParameter("cpf");
		
		
		try {
			Cliente nov = new Cliente();
			nov.setCpf(Integer.parseInt(cpf));
			ClienteDAO_Estoque novo = new ClienteDAO_Estoque();
			novo.removeCliente(nov);
			request.getRequestDispatcher("avisoMenu.html").forward(request, response);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	}

