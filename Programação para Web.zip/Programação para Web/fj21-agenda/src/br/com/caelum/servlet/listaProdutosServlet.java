package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ProdutoDAO_Estoque;
import br.com.caelum.modelo.Produto;

@WebServlet(name="listarProdutos", urlPatterns = {"/produtos"})
public class listaProdutosServlet extends HttpServlet{

	protected void service(HttpServletRequest request, HttpServletResponse response) 
	throws ServletException ,IOException {
		
		try {
			ArrayList<Produto> listaProduto = new ArrayList<Produto>();
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			ProdutoDAO_Estoque dao = new ProdutoDAO_Estoque();
			dao.apresentaProdutos(listaProduto);
			Produto p = new Produto();
			    out.println("<html>");
				out.println("<body>");
				out.println("<center><p style=\"font-size: 30px; color#767676\">Lista de Produtos</p></center>"); 
				out.println("<center><table widht=\"5\" cellspacing =\"1\" border =\"1\" bg color =\"11B6ED\" >");
				out.println("<tr>");
				out.println("<th>ID</th> ");
				out.println("<th>Marca</th>");
				out.println("<th>Preco Unitario</th>");
				out.println("<th>Quantidade no Estoque</th>");
				out.println("<th>FORNECEDOR</th>");
				out.println("</tr>");
				
				for(Produto p1 : listaProduto){
					p = p1;
					 out.println("<tr>");
					 out.println("<th>"+p.getId()+"</th>");
						out.println("<th>"+p.getMarca()+"</th>");
						out.println("<th>"+p.getPreco()+"</th>");
						out.println("<th>"+p.getQuantidade_estoque()+"</th>");
						out.println("<th>"+p.getFornecedor()+"</th>"); 
				}
				out.println("</tr>");
				out.println("</tbody>");
				
				out.println("</center></table>");
				out.println("<center><a href = \"http://localhost:8080/fj21-agenda/adiciona-produto.html\">Incluir Produto</a></center>");
				out.println("<center><a href = \"http://localhost:8080/fj21-agenda/altera-produto.html\">Alterar Produto</a></center>");
				out.println("<center><a href = \"http://localhost:8080/fj21-agenda/exclui-produto.html\">Excluir Produto</a></center>");

				out.println("</div>");
				out.println("</form>");
				out.println("</section> ");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}

