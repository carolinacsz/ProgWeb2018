package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ClienteDAO_Estoque;

import br.com.caelum.modelo.Cliente;



@WebServlet("/adicionaCliente")
public class AdicionaClienteServlet extends HttpServlet
{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

@Override
protected void doPost(HttpServletRequest request, HttpServletResponse response)
		throws IOException,ServletException  {
	// TODO Auto-generated method stub
	
PrintWriter out = response.getWriter();
String cpf = request.getParameter("cpf");
String nome = request.getParameter("nome");
String usuario = request.getParameter("usuario");
String senha = request.getParameter("senha");
String endereco = request.getParameter("endereco");
String email = request.getParameter("email");
String telefone = request.getParameter("telefone");

try{
Cliente novo = new Cliente();
novo.setCpf(Integer.parseInt(cpf));
novo.setNome(nome);
novo.setUsuario(usuario);
novo.setSenha(senha);
novo.setEndereco(endereco);
novo.setEmail(email);
novo.setTelefone(Integer.parseInt(telefone));

		ClienteDAO_Estoque f1 = new ClienteDAO_Estoque();
		f1.adicionar(novo);
		request.getRequestDispatcher("avisoMenu.html").forward(request, response);
}
	catch(SQLException e){
		e.printStackTrace();
	}
}
}
	




