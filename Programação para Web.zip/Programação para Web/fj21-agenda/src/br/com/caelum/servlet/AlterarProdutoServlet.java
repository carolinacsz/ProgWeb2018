package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ProdutoDAO_Estoque;
import br.com.caelum.modelo.Produto;

@WebServlet("/alteraProduto")
public class AlterarProdutoServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws IOException,ServletException  {
		
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		String marca = request.getParameter("marca");
		String preco = request.getParameter("preco");
		String fornecedor = request.getParameter("fornecedor");
		String quantidade_estoque = request.getParameter("quantidade_estoque");
		
		try {
			Produto novo = new Produto();
			novo.setId(Integer.parseInt(id));
			novo.setMarca(marca);
			novo.setPreco(Float.parseFloat(preco));
			novo.setFornecedor(fornecedor);
			novo.setQuantidade_estoque(Integer.parseInt(quantidade_estoque));
			ProdutoDAO_Estoque f1 = new ProdutoDAO_Estoque();
			f1.altera(novo);
			
			request.getRequestDispatcher("aviso.html").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();	// TODO: handle exception
		}
		}
		}


