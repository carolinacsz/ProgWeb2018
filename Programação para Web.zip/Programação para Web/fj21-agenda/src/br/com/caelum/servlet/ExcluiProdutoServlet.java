package br.com.caelum.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.caelum.jdbc.dao.ProdutoDAO_Estoque;
import br.com.caelum.modelo.Produto;

@WebServlet("/excluiProduto")
public class ExcluiProdutoServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws IOException,ServletException  {
		PrintWriter out = response.getWriter();
		String id = request.getParameter("id");
		try {
			Produto novo = new Produto();
			novo.setId(Integer.parseInt(id));
			ProdutoDAO_Estoque novo2 = new ProdutoDAO_Estoque();
			novo2.remove(novo);
			request.getRequestDispatcher("aviso.html").forward(request, response);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	}

