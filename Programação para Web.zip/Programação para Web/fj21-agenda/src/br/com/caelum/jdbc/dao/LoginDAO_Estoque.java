package br.com.caelum.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.annotation.WebServlet;

import br.com.caelum.jdbc.ConnectionFactory;
import br.com.caelum.modelo.Cliente;



public class LoginDAO_Estoque {
	private Connection connection;
	static String local;
public LoginDAO_Estoque() throws SQLException{
	this.connection = new ConnectionFactory().getConnection();	
	criarTabela();
}
public void criarTabela(){
	try{
		String criartabela = "CREATE TABLE IF NOT EXISTS cliente("
			+ "id_cliente BIGINT NOT NULL AUTO_INCREMENT,"
			+ "cpf int,"
			+ "nome varchar(50),"
			+ "usuario varchar(20),"
			+ "senha varchar(20),"
			+ "endereco varchar(50),"
			+ "email varchar(50),"
			+ "telefone int,"
			+ "primary key (id_cliente)"
			
			+")";
		Statement st = connection.createStatement();
		int i = st.executeUpdate(criartabela);
		if(i == -1){
			throw new RuntimeException("db error : " + criartabela);
		}
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}


public boolean verificarUsuario(String usuario,String senha) {
	Cliente n = null;
	Statement state = null;
	ResultSet rs = null;
	try {
	 state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
	 rs = state.executeQuery("SELECT * FROM cliente where usuario = '" + usuario + "' and senha = '" + senha + "'");
	 return rs.next();
	} catch (Exception e) {
		System.out.println("Erro ocorrido : n" + e);// TODO: handle exception
	return false;
	}finally{
	if(state != null){
		try {
			state.close();
		} catch (Exception e2) {
			e2.printStackTrace();// TODO: handle exception
		}
	}if(rs!= null){
		try{
			rs.close();
		}catch(SQLException e){
			e.printStackTrace();
		}
	}
	
}
	}}


