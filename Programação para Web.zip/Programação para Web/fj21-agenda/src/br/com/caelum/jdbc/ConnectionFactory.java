package br.com.caelum.jdbc;

import java.sql.*;




//Classe que fabrica conex�es

public class ConnectionFactory {

public static final String DRIVER = "com.mysql.jdbc.Driver";
public static final String URL = "jdbc:mysql://localhost:3306/fj21";
public static final String USER = "root";
public static final String PASSWORD = "";
		 public  Connection getConnection() throws SQLException {             
		         try {
					Class.forName(DRIVER);
					return DriverManager.getConnection(URL, USER, PASSWORD);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					throw new RuntimeException(e);
				}
				   
		    }
	}

