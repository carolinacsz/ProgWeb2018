package br.com.caelum.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.com.caelum.jdbc.ConnectionFactory;
import br.com.caelum.modelo.Produto;

public class ProdutoDAO_Estoque {
	
   private Connection connection;

//Aqui esta a vantagem da DAO, para obter a conex�o a cada classe de produto
//basta apenas realizar o construtor abaixo

public ProdutoDAO_Estoque() throws SQLException {

		this.connection = new ConnectionFactory().getConnection();
	
}


//consultar produtos 
public List<Produto> apresentaProdutos(ArrayList<Produto> listaProduto){
	try{
		String sql = "select * from produto";
		Statement st = connection.createStatement();
		ResultSet rs = st.executeQuery(sql);
		
	
	
	while(rs.next()){
		//Criando o objeto que ira armazenar o resultado
	Produto  novo = new Produto(rs.getInt("id"),rs.getString("marca"), rs.getFloat("preco"),
			rs.getString("fornecedor"),rs.getInt("quantidade_estoque"));
		listaProduto.add(novo);
	}
	st.close();
	rs.close();

	
} catch(SQLException e){
	throw new RuntimeException(e);
}
return listaProduto;
}

public List<Produto> listaCompraProdutos(ArrayList<Produto> lista){
	try{
		String sql = "select * from produto";
		Statement st = connection.createStatement();
		ResultSet rs = st.executeQuery(sql);
	while(rs.next()){
	Produto  novo = new Produto(rs.getInt("id"),rs.getString("marca"), rs.getFloat("preco"),rs.getInt("quantidade_estoque"));
		lista.add(novo);
	}
	st.close();
	rs.close();
} catch(SQLException e){
	throw new RuntimeException(e);
}

	return lista;
}

// adicionar produtos
public void adiciona (Produto produto){
	
	String sql = "insert into produto (marca,preco,fornecedor,quantidade_estoque) values (?,?,?,?)";
	
	try{
		// prepared statement para inser��o
		PreparedStatement stmt = connection.prepareStatement(sql);
		//Seta os valores
		stmt.setString(1, produto.getMarca());
		stmt.setFloat(2, produto.getPreco());
		stmt.setString(3, produto.getFornecedor());
		stmt.setInt(4, produto.getQuantidade_estoque());
		//Executa a statement
		stmt.execute();
		//stmt.executeUpdate(sql);
		stmt.close();
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
}
public void altera(Produto produto){
	try{
		String sql = "update produto set marca=?, preco=?,fornecedor=?,quantidade_estoque=? where id=?";
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setString(1, produto.getMarca());
		stmt.setFloat(2, produto.getPreco());
		stmt.setString(3, produto.getFornecedor());
		stmt.setInt(4, produto.getQuantidade_estoque());
		stmt.setInt(5, produto.getId());
		stmt.executeUpdate();
		stmt.close();
	}catch (SQLException e){
		throw new RuntimeException(e);
	}
			
}

public void finalizaCompra(Produto produto){
	
	try {
		String sql = "update produto set quantidade_estoque = quantidade_estoque -?  where id=?";
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setInt(1, produto.getQuantidade_estoque());
		stmt.setInt(2, produto.getId());
	    stmt.executeUpdate();
		stmt.close();
	} catch (Exception e) {
		throw new RuntimeException(e);	// TODO: handle exception
	}
}
public void remove(Produto produto) throws SQLException{
	try{
	PreparedStatement stmt = connection.prepareStatement("delete from produto where id=?");
	stmt.setInt(1, produto.getId());
	stmt.execute();
	stmt.close();
}catch(SQLException e){
	throw new RuntimeException(e);
}
}}
