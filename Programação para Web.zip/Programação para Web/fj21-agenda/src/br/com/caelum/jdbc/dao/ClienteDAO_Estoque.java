package br.com.caelum.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import java.sql.SQLException;

import br.com.caelum.jdbc.ConnectionFactory;
import br.com.caelum.modelo.Cliente;


public class ClienteDAO_Estoque {
private Connection connection;

public ClienteDAO_Estoque() throws SQLException {
	
		this.connection = new ConnectionFactory().getConnection();
		criarTabela();
	
}

public void criarTabela() throws SQLException{
	try{
	String criartabela = "CREATE TABLE IF NOT EXISTS Cliente("
		+ "id_cliente BIGINT NOT NULL AUTO_INCREMENT,"
		+ "cpf int,"
		+ "nome varchar(50),"
		+ "usuario varchar(20),"
		+ "senha varchar(20),"
		+ "endereco varchar(50),"
		+ "email varchar(50),"
		+ "telefone int,"
		+ "primary key (id_cliente)"
		
		+")";
	Statement st = connection.createStatement();
	int i = st.executeUpdate(criartabela);
	if(i == -1){
		throw new RuntimeException("db error : " + criartabela);
	}
	}catch(Exception e){
		throw new RuntimeException(e);
	}
}
public void adicionar (Cliente Cliente){
	String sql = "insert into Cliente (cpf,nome,usuario,senha,endereco,email,telefone) values(?,?,?,?,?,?,?)";
try{
	PreparedStatement stmt =connection.prepareStatement(sql);
	stmt.setInt(1, Cliente.getCpf());
	stmt.setString(2, Cliente.getNome());
	stmt.setString(3, Cliente.getUsuario());
	stmt.setString(4, Cliente.getSenha());
	stmt.setString(5, Cliente.getEndereco());
	stmt.setString(6, Cliente.getEmail());
	stmt.setInt(7, Cliente.getTelefone());
	stmt.execute();
	stmt.close();
}catch(SQLException e){
	throw new  RuntimeException(e);

}
}
 public Cliente consultarCPF (Cliente cliente) throws SQLException {
	Cliente novo = null;
	 try {
		String sql = " select cpf,nome,usuario,senha,endereco,email,telefone where cpf =?";
	   PreparedStatement stmt = connection.prepareStatement(sql);
	   stmt.setInt(1, cliente.getCpf());
	   ResultSet rs = stmt.executeQuery();
	   if(rs.next()){
		  novo = new Cliente();
		 novo.setCpf(rs.getInt("cpf"));
		 novo.setNome(rs.getString("nome"));
		 novo.setUsuario(rs.getString("usuario"));
		 novo.setSenha(rs.getString("senha"));
		 novo.setEndereco(rs.getString("endereco"));
		 novo.setEndereco(rs.getString("email"));
		 novo.setTelefone(rs.getInt("telefone"));
		   
	   }
	} catch (Exception e) {
		// TODO: handle exception
		System.err.println("Erro na sele��o por CPF");
	}{
		
	}
	return novo;
	
 }
 public void removeCliente(Cliente cliente){
	 try {
		 PreparedStatement stmt = connection.prepareStatement("delete from cliente where cpf=?");
	stmt.setInt(1, cliente.getCpf());
	stmt.execute();
	stmt.close();
	 } catch (Exception e) {
		 throw new RuntimeException(e);
	}{
		 
	 }
 }
 
 public boolean validaCPF(String cpf,String usuario){
	 Statement state = null;
	 ResultSet rs = null;
	 try {
		 state = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
		 rs = state.executeQuery("SELECT * FROM cliente where cpf = '" + cpf + "' and usuario= '" + usuario +"'");
	return rs.next();
	 } catch (Exception e) {
		 System.out.println("Erro ocorrido : n" + e);	// TODO: handle exception
		 return false;
	}finally{
		if(state != null){
			try {
				state.close();
			} catch (Exception e2) {
				e2.printStackTrace();// TODO: handle exception
			}
		}if(rs!= null){
			try{
				rs.close();
			}catch(SQLException e){
				e.printStackTrace();
			} 
 } 
}
}
public void alterarCadastro (Cliente cliente){
	
	try{
		String sql = "update cliente set nome=?, usuario=?, senha=?, endereco=?,email=?, telefone=? where cpf =?";
		PreparedStatement stmt = connection.prepareStatement(sql);
		stmt.setString(1, cliente.getNome());
		stmt.setString(2, cliente.getUsuario());
		stmt.setString(3, cliente.getSenha());
		stmt.setString(4, cliente.getEndereco());
		stmt.setString(5, cliente.getEmail());
		stmt.setInt(6, cliente.getTelefone());
		stmt.setInt(7, cliente.getCpf());
		stmt.executeUpdate();
		stmt.close();
	}catch(SQLException e){
		throw new RuntimeException(e);
	}
}
}