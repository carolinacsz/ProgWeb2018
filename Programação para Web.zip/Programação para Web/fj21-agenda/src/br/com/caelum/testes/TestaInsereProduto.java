package br.com.caelum.testes;

import java.sql.SQLException;

import br.com.caelum.jdbc.dao.ProdutoDAO_Estoque;

import br.com.caelum.modelo.Produto;

public class TestaInsereProduto {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		//Inserindo os produtoa
Produto produto = new Produto();
produto.setMarca("jj");
//produto.setPreco(3);
produto.setFornecedor("Yan");
//produto.setQuantidade_estoque(3);

/*Produto produto1 = new Produto();
produto1.setMarca("MARIO");
produto1.setPreco(20);
produto1.setFornecedor("FUNASA");
produto1.setQuantidade_estoque(1);*/
//gravando nessa conexao criada
ProdutoDAO_Estoque dao3 = new ProdutoDAO_Estoque();

dao3.adiciona(produto);
//dao.adiciona(produto1);
System.out.println("Gravado!");
	}
	

}
