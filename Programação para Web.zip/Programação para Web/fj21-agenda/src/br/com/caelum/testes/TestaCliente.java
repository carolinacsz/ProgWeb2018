package br.com.caelum.testes;

import java.sql.SQLException;


import br.com.caelum.jdbc.dao.ClienteDAO_Estoque;
import br.com.caelum.modelo.Cliente;


public class TestaCliente {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub


/*Funcionario funcionario1 = new Funcionario();
funcionario1.setNome("Joao");
funcionario1.setUsuario("leo");
funcionario1.setSenha("leo");*/

Cliente funcionario = new Cliente();

funcionario.setCpf(2345);
funcionario.setNome("yan ");
funcionario.setUsuario("2");
funcionario.setSenha("1");
funcionario.setEndereco("TESTANDO");
funcionario.setEmail("yan");
funcionario.setTelefone(123);

ClienteDAO_Estoque dao = new ClienteDAO_Estoque();
dao.adicionar(funcionario);

System.out.println("Salvo na tabela cliente!");

	//	Funcionario remove = new Funcionario();
		//remove.setId_funcionario(2);
//FuncionarioDAO_Estoque funcionario2 = new FuncionarioDAO_Estoque();
//funcionario2.remove(remove);
//System.out.println("Removido");

	}

}
