package br.com.caelum.modelo;

public class Cliente {
private int id_cliente;
private int cpf;
private String nome;
private String usuario;
private String senha;
private String endereco;
private String email;
private int telefone;

public Cliente() {
	
}

public Cliente(int id_cliente, int cpf, String nome, String usuario,
	String senha, String endereco, String email, int telefone) {
	this.id_cliente = id_cliente;
	this.cpf = cpf;
	this.nome = nome;
	this.usuario = usuario;
	this.senha = senha;
	this.endereco = endereco;
	this.email = email;
	this.telefone = telefone;
}

public int getId_cliente() {
	return id_cliente;
}

public void setId_cliente(int id_cliente) {
	this.id_cliente = id_cliente;
}

public int getCpf() {
	return cpf;
}

public void setCpf(int cpf) {
	this.cpf = cpf;
}

public String getNome() {
	return nome;
}

public void setNome(String nome) {
	this.nome = nome;
}

public String getUsuario() {
	return usuario;
}

public void setUsuario(String usuario) {
	this.usuario = usuario;
}

public String getSenha() {
	return senha;
}

public void setSenha(String senha) {
	this.senha = senha;
}

public String getEndereco() {
	return endereco;
}

public void setEndereco(String endereco) {
	this.endereco = endereco;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public int getTelefone() {
	return telefone;
}

public void setTelefone(int telefone) {
	this.telefone = telefone;
}




}
