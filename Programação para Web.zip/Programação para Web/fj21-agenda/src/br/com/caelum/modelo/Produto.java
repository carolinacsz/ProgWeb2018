package br.com.caelum.modelo;

public class Produto {
private int id;
private String marca;
private float preco;
private String fornecedor;
private int quantidade_estoque;

public Produto(int id, String marca, float preco, int quantidade_estoque) {

	this.id = id;
	this.marca = marca;
	this.preco = preco;
	this.quantidade_estoque = quantidade_estoque;
}


public Produto(int id, int quantidade_estoque) {
	
	this.id = id;
	this.quantidade_estoque = quantidade_estoque;
}


public Produto(int id, String marca, float preco, String fornecedor,
	int quantidade_estoque) {

	this.id = id;
	this.marca = marca;
	this.preco = preco;
	this.fornecedor = fornecedor;
	this.quantidade_estoque = quantidade_estoque;
}

public Produto() {
	// TODO Auto-generated constructor stub
}

public void imprime(){
	System.out.println("Opa");
}
public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getMarca() {
	return marca;
}

public void setMarca(String marca) {
	this.marca = marca;
}

public float getPreco() {
	return preco;
}

public void setPreco(float preco) {
	this.preco = preco;
}

public String getFornecedor() {
	return fornecedor;
}

public void setFornecedor(String fornecedor) {
	this.fornecedor = fornecedor;
}

public int getQuantidade_estoque() {
	return quantidade_estoque;
}

public void setQuantidade_estoque(int quantidade_estoque) {
	this.quantidade_estoque = quantidade_estoque;
}

}
